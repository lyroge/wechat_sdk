# -*- coding: UTF-8 -*-

WECHAT_API_DOMAIN_LIST = [
    'api.weixin.qq.com',
    'sh.api.weixin.qq.com',
    'sz.api.weixin.qq.com',
    'hk.api.weixin.qq.com'
]
