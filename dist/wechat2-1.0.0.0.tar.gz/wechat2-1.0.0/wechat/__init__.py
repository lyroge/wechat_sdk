# -*- coding: UTF-8 -*-
"""
使用说明：
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~
微信公众平台开发官方文档
https://mp.weixin.qq.com/wiki?t=resource/res_main&id=mp1445241432&token=&lang=zh_CN
"""

__version__ = '1.0.0'

__author__ = 'songzhengang'


def get_version():
    return __version__
