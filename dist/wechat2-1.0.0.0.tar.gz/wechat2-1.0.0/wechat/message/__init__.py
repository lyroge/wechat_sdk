# -*- coding: UTF-8 -*-

from hander import BaseHandler

from response import TextResponse
from response import ImageResponse
from response import VideoResponse
from response import VoiceResponse
from response import NewsResponse
